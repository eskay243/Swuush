var server_domain = 'http://swuush.edstudioz.com/';
var secret_key = "swuush_key";
var wordpress = false;


